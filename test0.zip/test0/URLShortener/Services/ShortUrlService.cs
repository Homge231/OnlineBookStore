﻿using MongoDB.Driver;
using URLShortener.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace URLShortener.Services
{
    public class ShortUrlService
    {
        private readonly IMongoCollection<ShortUrl> _urls;

        public ShortUrlService(MongoDBSettings settings)
        {
            var client = new MongoClient(settings.ConnectionString);
            var database = client.GetDatabase(settings.DatabaseName);
            _urls = database.GetCollection<ShortUrl>("shorturls");
        }

        public string GenerateShortCode()
        {
            // Sử dụng một phương thức để tạo short code ngẫu nhiên
            return Guid.NewGuid().ToString().Substring(0, 8);
        }

        public async Task CreateAsync(ShortUrl shortUrl)
        {
            await _urls.InsertOneAsync(shortUrl);
        }

        public async Task<List<ShortUrl>> GetAllAsync()
        {
            return await _urls.Find(url => true).ToListAsync();
        }

        public async Task<ShortUrl> GetByShortCodeAsync(string shortCode)
        {
            return await _urls.Find(url => url.ShortCode == shortCode).FirstOrDefaultAsync();
        }

        public async Task UpdateClicksAsync(string id, int clicks)
        {
            var filter = Builders<ShortUrl>.Filter.Eq(url => url.Id, id);
            var update = Builders<ShortUrl>.Update.Set(url => url.Clicks, clicks);
            await _urls.UpdateOneAsync(filter, update);
        }
    }
}
