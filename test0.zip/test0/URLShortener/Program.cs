﻿using URLShortener.Models;
using URLShortener.Services;
using Microsoft.Extensions.Options;

var builder = WebApplication.CreateBuilder(args);

// Cấu hình MongoDB
builder.Services.Configure<MongoDBSettings>(builder.Configuration.GetSection("MongoDB"));
builder.Services.AddSingleton<ShortUrlService>(sp =>
{
    var settings = sp.GetRequiredService<IOptions<MongoDBSettings>>().Value;
    return new ShortUrlService(settings);
});

// Thêm Controller với View
builder.Services.AddControllersWithViews();

var app = builder.Build();

// Cấu hình Middleware
if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseAuthorization();

// Dùng MapControllers thay cho UseEndpoints (sửa lỗi ASP0014)
app.MapControllers();

app.Run();
